//Shamus Sage
class DObj {
  int randpick;
  String[] Do ={"Air", "Airport", "Album", "Anchor", "Apple", "Apron",
    "Art", "Arrow", "Ashtray", "Awning", "Baby", "Bagel", "Ball", "Banana"
    , "Bicycle", "Blanket", "Blouse", "Boat", "Book", "Bottle", "Box", "Bread",
    "Brick", "Bridge", "Brush", "Button", "Cabin", "Cake", "Camera", "Candle",
    "Car", "Carrot", "Castle", "Cat", "Chair", "Cheese", "Chicken", "Clock",
    "Coat", "Coin", "Computer", "Cookie", "Couch", "Crown", "Cup", "Desk",
    "Diamond", "Diary", "Dinner", "Dog", "Doll", "Door", "Dress", "Drum",
    "Eagle", "Egg", "Engine", "Envelope", "Fence", "Film", "Fire", "Fish",
    "Flag", "Flashlight", "Flower", "Fork", "Fountain", "Frame", "Frisbee",
    "Frog", "Game", "Garage", "Gate", "Glass", "Glove", "Goal", "Guitar", "Hammer",
    "Hat", "Helmet", "Honey", "Horse", "House", "Jacket", "Jeans", "Journal", "Juice",
    "Key", "Kite", "Knife", "Ladder", "Lamp", "Lantern", "Laptop", "Letter", "Lizard",
    "Lock", "Lunch", "Magazine", "Magnet"
  };
  void pickDo(int randpick,int x,int y) {
    if (randpick < 1) {
      text("unlucky randpick picked number that rounded to zero ", width/2, height/2);
    } else {
      for(String i :Do) {
        DoInventory.append(i);
      };
      text(DoInventory.get(randpick), x, y);
    }
  }
}
