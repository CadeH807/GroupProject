class Button {
  int x,y;
  void Button (int x, int y){
    x = this.x;
    y= this.y;
  
  }
}
