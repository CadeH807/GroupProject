//class Sentence {
//  Noun n1;
//  void CreateSentence{


//  }
//}
class Sentence {
  Noun n1;
  Verb v1;
  Adj adj1;
  Adv adv1;
  DObj d1;
  void createSentence(int y) {
    n1 = new Noun(50, y, int(random(100)));
    n1.Picknoun(50, y, int(random(100)));
    v1 = new Verb(0, y);
    v1.Pickverbs(150, y, int(random(100)));
    adj1= new Adj();
    adj1.PickAdj(200, y);
    adv1= new Adv();
    adv1.PickAdv(100, y);
    d1= new DObj();
    d1.pickDo(int(random(100)),250,y);
  }
}
