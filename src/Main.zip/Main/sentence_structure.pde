//class Sentence {
//  Noun n1;
//  void CreateSentence{

    
//  }
//}
class Sentence { 
    Noun n1; 
    Verb v1;
    Adj adj1;
    Adv adv1;
    void createSentence() { 
        n1 = new Noun(100,100,int(random(100))); 
        n1.Picknoun(100,100);
        v1 = new Verb(0,0);
        v1.Pickverbs(50,100,int(random(100)));
        adj1= new Adj();
        adj1.PickAdj(150,100);
        adv1= new Adv();
        adv1.PickAdv(200,100);
    } 
}
