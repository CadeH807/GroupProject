// Shamus Sage
int gameState = 0;
PImage myCursor1, myCursor2;
StringList NounInventory = new StringList();
StringList VerbInventory = new StringList();
StringList AdjInventory = new StringList();
StringList AdvInventory = new StringList();
StringList DoInventory = new StringList();
float decide= random(1, 4);
float decide2= random(1, 5);
int i;
String input= " ";
String nounpick, DOpick, verbpick, adjpick, advpick="";
Noun noun1, noun2, noun3, noun4;
Verb verb1, verb2, verb3, verb4;
Adj adj1, adj2, adj3, adj4;
Adv adv1, adv2, adv3, adv4;
Sentence s1, s2;
MadLib m1;
void setup() {


  size(500, 500);
  myCursor1 = loadImage("New Piskel-1.png.png");
  myCursor1.resize(50, 50);

  myCursor2 = loadImage("New Piskel-2.png.png");
  myCursor2.resize(50, 50);
  //noun1 = new Noun();
  //noun2 = new Noun();
  //noun3 = new Noun();
  //noun4 = new Noun();
  //  noun1 = new Noun(100, 100);
  //  noun2 = new Noun(200, 100);
  //  noun3 = new Noun(300, 100);
  //  noun4 = new Noun(400, 100);
  //  verb1= new Verb(100, 100);
  //  verb2= new Verb(100, 100);
  //  verb3= new Verb(100, 100);
  //  verb4= new Verb(100, 100);
  //  adj1 = new Adj();
  //  adj2 = new Adj();
  //  adj3 = new Adj();
  //  adj4 = new Adj();
  //  adv1 =new Adv();
  //  adv2 =new Adv();
  //  adv3 =new Adv();
  //  adv4 =new Adv();

  s1= new Sentence();
  s2= new Sentence();
  s1.createSentence(100);
  m1 =new MadLib();
  //s2.createSentence(200);
}

void draw() {
  background(0);

  if (key==ENTER) {
    input.replace("\n", "");
    println(input);
    m1.Madlibber(100);
  }else if(key== SHIFT){
    s2.createSentence(200);
    input=" ";
    
  }
  // m1.Madlibber(50);
  if (gameState == 0) {
    initScreen();
  } else if (gameState == 1) {
    gameLoop();
    imageMode(CENTER);
   
    if (decide2 <2) {
      text("give adverb", width/2, height/2);
    } else if (decide2 <3) {
      text("give verb", width/2, height/2);
    } else if (decide2 <4) {
      text("give Noun", width/2, height/2);
    }

    if (mousePressed) {
      image(myCursor2, mouseX, mouseY);
    } else {
      image(myCursor1, mouseX, mouseY);
    }
  }
  //noun1.Picknoun(50, 100);
  //noun2.Picknoun(100, 100);
  //noun3.Picknoun(150, 100);
  //noun4.Picknoun(200, 100);
  //verb1.Pickverbs(50, 50);
  //verb2.Pickverbs(100, 50);
  //verb3.Pickverbs(150, 50);
  //verb4.Pickverbs(200, 50);
  //adj1.PickAdj(50, 150);
  //adj2.PickAdj(100, 150);
  //adj3.PickAdj(150, 150);
  //adj4.PickAdj(200, 150);
  //adv1.PickAdv(50,200);
  //adv2.PickAdv(100,200);
  //adv3.PickAdv(150,200);
  //adv4.PickAdv(200,200);
  input.replace("\n", "");
   input.replace("\u000e", " ").replace("\u000f", " ");
  
}
void initScreen() {

  fill(255);
  textAlign(CENTER);
  textSize(32);
  text("Nounsense", width/2, height/3);
  //m1.Madlibber(50);

  textSize(16);
  text("Click anywhere to start", width/2, height/2);
}
void gameLoop() {

  fill(255);
  noCursor();
  if (key==ENTER) {
   
  }
}
void mousePressed() {
  if (gameState == 0) {
    startGame();
  }
}
void startGame() {
  gameState = 1;
}
void keyPressed() {
  input = input + key;
  // text(input ,150,150);
  println(input);
  if (key == SHIFT) {
    
    
    
  }
}
