class MadLib {






  void Madlibber(int y) {
    if (key==ENTER) {
      input.replace("\n", "");
      println(input);

      if (decide2 <2) {
        text(nounpick, 50, y);
        text(  input.replace("\n", ""), 100, y);
        text(verbpick, 150, y);
        text(adjpick, 200, y);
        text(DOpick, 250, y);
      } else if (decide2 <3) {
        text(nounpick, 50, y);
        text(advpick, 100, y);
        text(  input.replace("\n", ""), 150, y);
        text(adjpick, 200, y);
        text(DOpick, 250, y);
      } else if (decide2 <4) {
        text(  input.replace("\n", ""), 50, y);
        text(advpick, 100, y);
        text(verbpick, 150, y);
        text(adjpick, 200, y);
        text(DOpick, 250, y);
      }else if (decide2 <5) {
        text(nounpick, 50, y);
        text(advpick, 100, y);
        text(verbpick, 150, y);
        text(input.replace("\n", ""), 50, y);
        text(DOpick, 250, y);
      }
      if (decide2 <2) {
        text("give adverb", width/2, height/2);
      } else if (decide2 <3) {
        text("give verb", width/2, height/2);
      } else if (decide2 <4) {
        text("give Noun", width/2, height/2);
      }
    }
  }
}
